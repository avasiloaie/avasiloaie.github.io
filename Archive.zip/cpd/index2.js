var antlr4 = require('antlr4/index');
var cpdLexer = require('./cpdLexer').cpdLexer;
var cpdParser = require('./cpdParser').cpdParser;

function parse_routine2(code) {
    var chars = new antlr4.InputStream(code);
    var lexer = new cpdLexer(chars);
    var tokens  = new antlr4.CommonTokenStream(lexer);
    var parser = new cpdParser(tokens);
    parser.buildParseTrees = true;
    var cst = parser.compileUnit();
    return cst;
}

module.exports = {
    parse_routine2
}