module.exports = {
  entry: "./index2.js",
  output: {
    filename: "bundle.js",
    libraryTarget: 'var',
    library: 'CompilerDependency'
  },
  node: {
    module: "empty",
    net:"empty",
    fs: "empty"
  }
}